# FCO 0.7.2

* New seed argument in gen_fit for reproducible cutoffs

------------------------------------------------------------------------

# FCO 0.7.1

* Added a `NEWS.md` file to track changes to the package.
* Minor revisions to tests

# FCO 0.7.0

* Speed improvements in the vignette
* New naming scheme
* Minor revisions to the descriptions and references
* Added contributor


# FCO 0.69

* Bug fixes in gen_fit for OS compatibility
* Improvements in the vignette

# FCO 0.67

* First stable release
