library(testthat)
library(FCO)

test_check("FCO")
